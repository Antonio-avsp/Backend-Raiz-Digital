package com.raizdigital.api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RaizDigitalApiApplication {

    public static void main(String[] args) {
        // --- CONFIGURAÇÃO MANUAL DO BANCO DE DADOS ---
       
        
        System.setProperty("spring.datasource.url", "jdbc:mysql://localhost:3306/raiz_digital?createDatabaseIfNotExist=true&serverTimezone=UTC");
        System.setProperty("spring.datasource.username", "root");
        System.setProperty("spring.datasource.password", "root"); 
        
        System.setProperty("spring.jpa.hibernate.ddl-auto", "update");
        System.setProperty("spring.jpa.show-sql", "true");
        System.setProperty("spring.jpa.properties.hibernate.dialect", "org.hibernate.dialect.MySQLDialect");
        
        // Inicia o sistema
        SpringApplication.run(RaizDigitalApiApplication.class, args);
    }
}