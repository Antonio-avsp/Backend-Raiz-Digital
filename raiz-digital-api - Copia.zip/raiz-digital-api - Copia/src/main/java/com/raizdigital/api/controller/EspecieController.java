package com.raizdigital.api.controller;

import com.raizdigital.api.model.Especie;
import com.raizdigital.api.repository.EspecieRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/especies")
@CrossOrigin(origins = "*")
public class EspecieController {

    @Autowired
    private EspecieRepository repository;

    @GetMapping
    public List<Especie> listar() {
        return repository.findAll();
    }

    @PostMapping
    public Especie cadastrar(@RequestBody Especie especie) {
        return repository.save(especie);
    }
    


    // ATUALIZAR (PUT)
    @PutMapping("/{id}")
    public Especie atualizar(@PathVariable Long id, @RequestBody Especie especieAtualizada) {
        return repository.findById(id).map(especie -> {
            // Atualiza os campos
            especie.setNome(especieAtualizada.getNome());
            especie.setDescricao(especieAtualizada.getDescricao());
            // Se quiser permitir editar outros campos, adicione aqui (ex: validade)
            return repository.save(especie);
        }).orElse(null);
    }

    // DELETAR (DELETE)
    @DeleteMapping("/{id}")
    public void deletar(@PathVariable Long id) {
        repository.deleteById(id);
    }
    
}