package com.raizdigital.api.model;

import jakarta.persistence.*;

@Entity
@Table(name = "especies")
public class Especie {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_especie") 
    private Long id;

    @Column(nullable = false)
    private String nome;

    @Column(name = "nome_cientifico")
    private String nomeCientifico;

    private String categoria;

    // Garante que a validade nunca vá vazia
    @Column(name = "periodo_validade_dias", nullable = false)
    private Integer periodoValidadeDias = 30;

    private String descricao;
    
    private Boolean ativo = true;

    // --- CÓDIGO MANUAL (Essencial para o Create funcionar) os outros tava dando erro  ---

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getNome() { return nome; }
    public void setNome(String nome) { this.nome = nome; }

    public String getNomeCientifico() { return nomeCientifico; }
    public void setNomeCientifico(String nomeCientifico) { this.nomeCientifico = nomeCientifico; }

    public String getCategoria() { return categoria; }
    public void setCategoria(String categoria) { this.categoria = categoria; }

    public Integer getPeriodoValidadeDias() { return periodoValidadeDias; }
    public void setPeriodoValidadeDias(Integer periodoValidadeDias) { this.periodoValidadeDias = periodoValidadeDias; }

    public String getDescricao() { return descricao; }
    public void setDescricao(String descricao) { this.descricao = descricao; }

    public Boolean getAtivo() { return ativo; }
    public void setAtivo(Boolean ativo) { this.ativo = ativo; }
}